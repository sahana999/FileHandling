package day4;




import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;


public class FileHandlingDemo {
public static void main(String[] args) {
		
		String path = "C://file.txt";
		
		try {
		
			File f = new File(path);
			File f2 = new File("C://file.txt");
			new FileHandlingDemo().readFile(f);
			new FileHandlingDemo().printFile(f2);
			
			
		} catch (Exception e) {
				System.out.println(e);
		}
		
	}//end main
	
	
	public void printFile(File f2) throws Exception
	{
		System.out.println(" Printing ....");
		PrintWriter pw = new PrintWriter(f2);
		pw.append("dfverg");
		pw.close();
		System.out.println("done ---");
	}
	
	public void readFile(File f)throws IOException
	{
		BufferedReader br = new BufferedReader(new FileReader(f));
		
		String line = null;
		
		while((line = br.readLine())!=null)
		{
			System.out.println(line);
		}
	}
	
	
	public void Searchword(File f)throws IOException
	{
BufferedReader br = new BufferedReader(new FileReader(f));
		int count=0;
		String line = null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the word to search");
		String key=sc.nextLine();
		System.out.println("Line number:");
		while((line = br.readLine())!=null)
		{
			
			count++;
			if(line.contains(key))
			{
				
				
					System.out.println(count);
				
			}
			if(count==0)
			{
				
			
			
			System.out.println("The word does not exist in the file");
			}
		}
		
		
	}
}//end class



